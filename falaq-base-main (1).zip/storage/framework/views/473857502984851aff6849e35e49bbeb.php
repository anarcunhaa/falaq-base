<?php $__env->startSection('title', $evento->titulo . ' — FalaQ'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Formularço de envio de Pergunta -->
    <div class="col-md-5 mb-4">
        <div class="card shadow-sm p-3">
            <h4 class="fw-bold mb-3">💬 Faça sua Pergunta</h4>
            <form action="<?php echo e(route('eventos.perguntas.store', $evento->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="texto" class="form-label text-secondary">Texto da Pergunta</label>

                    <textarea name="texto" id="texto" rows="4" 
                              class="form-control bg-dark text-white border-secondary <?php $__errorArgs = ['texto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                              placeholder="Digite sua dúvida ou comentário para o palestrante..."><?php echo e(old('texto')); ?></textarea>

                    <?php $__errorArgs = ['texto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback fw-bold">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <?php if(auth()->guard()->check()): ?>
                    <button type="submit" class="btn btn-primary w-100 fw-bold">Enviar Pergunta</button>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-primary w-100 fw-bold">Entre para enviar uma pergunta</a>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <!-- Lista de Perguntas (TICKET #002) -->
    <div class="col-md-7">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="fw-bold m-0">📋 Perguntas do Evento</h4>
            <span class="text-secondary small">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('moderate', $evento)): ?>
                    <a href="<?php echo e(route('eventos.moderacoes', $evento)); ?>" class="me-3">Fila de moderação</a>
                <?php endif; ?>
                Total: <?php echo e($perguntas->total()); ?>

            </span>
        </div>

        <?php $__empty_1 = true; $__currentLoopData = $perguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pergunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php ($jaVotou = in_array($pergunta->id, $votadas, true)); ?>
            <div class="card mb-3 shadow-sm border-start border-4 border-primary">
                <div class="card-body">
                    <p class="fs-5 mb-2 text-white"><?php echo e($pergunta->texto); ?></p>
                    <div class="d-flex justify-content-between align-items-center text-secondary small">
                        <span>Por <strong><?php echo e($pergunta->user->name ?? 'Anônimo'); ?></strong></span>
                        <span><?php echo e($pergunta->created_at->format('d/m/Y H:i')); ?></span>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mt-3">
                        
                        <form action="<?php echo e(route('perguntas.votar', $pergunta)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                    class="btn btn-sm <?php echo e($jaVotou ? 'btn-primary' : 'btn-outline-primary'); ?>"
                                    aria-pressed="<?php echo e($jaVotou ? 'true' : 'false'); ?>"
                                    title="<?php echo e($jaVotou ? 'Clique para remover seu voto' : 'Votar nesta pergunta'); ?>">▲ <?php echo e($pergunta->votos_count); ?></button>
                        </form>

                        
                        <?php if(auth()->guard()->check()): ?>
                            <details class="small">
                                <summary class="text-secondary" style="cursor:pointer">🚩 Denunciar</summary>
                                <form action="<?php echo e(route('perguntas.moderar', $pergunta)); ?>" method="POST" class="mt-2">
                                    <?php echo csrf_field(); ?>
                                    <textarea name="motivo" rows="2" minlength="10" maxlength="255" required
                                              class="form-control form-control-sm bg-dark text-white border-secondary"
                                              placeholder="Explique por que esta pergunta é imprópria"></textarea>
                                    <button type="submit" class="btn btn-sm btn-outline-secondary mt-1">Enviar denúncia</button>
                                </form>
                            </details>
                        <?php endif; ?>

                        
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $pergunta)): ?>
                            <form action="<?php echo e(route('perguntas.destroy', $pergunta)); ?>" method="POST"
                                  onsubmit="return confirm('Excluir esta pergunta?')">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <?php if (isset($component)) { $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Excluir Pergunta <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $attributes = $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $component = $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="alert alert-dark text-center p-4">
                Nenhuma pergunta enviada ainda. Seja o primeiro!
            </div>
        <?php endif; ?>

        <!-- TICKET #002: Renderização dos Botões de Paginação -->
        <?php if(method_exists($perguntas, 'links')): ?>
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($perguntas->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/claude/falaq/falaq-base-main/resources/views/eventos/show.blade.php ENDPATH**/ ?>
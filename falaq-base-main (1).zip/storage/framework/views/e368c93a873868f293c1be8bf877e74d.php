<?php $__env->startSection('title', 'Eventos — FalaQ'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 mb-4">
        <h2 class="fw-bold">📅 Eventos Ativos</h2>
        <p class="text-muted">Selecione o evento para enviar e visualizar as perguntas em tempo real.</p>
        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('eventos.create')); ?>" class="btn btn-primary btn-sm fw-bold">+ Criar evento</a>
        <?php endif; ?>
    </div>

    <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-6 mb-4">
        <div class="card h-100 shadow-sm">
            <div class="card-body">
                <h4 class="card-title fw-bold text-white"><?php echo e($evento->titulo); ?></h4>
                <p class="card-text text-secondary"><?php echo e($evento->descricao); ?></p>
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <span class="badge bg-purple" style="background:#7c6af7;">
                        <?php echo e($evento->perguntas_count); ?> perguntas
                    </span>
                    <a href="<?php echo e(route('eventos.show', $evento->id)); ?>" class="btn btn-primary btn-sm">
                        Entrar no Evento &rarr;
                    </a>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/claude/falaq/falaq-base-main/resources/views/eventos/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Moderação — '.$evento->titulo); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="fw-bold m-0">🛡️ Fila de Moderação — <?php echo e($evento->titulo); ?></h4>
    <a href="<?php echo e(route('eventos.show', $evento->id)); ?>" class="btn btn-outline-secondary btn-sm">&larr; Voltar ao evento</a>
</div>

<?php $__empty_1 = true; $__currentLoopData = $moderacoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moderacao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="card mb-3 shadow-sm">
        <div class="card-body">
            <p class="fs-5 mb-1 text-white"><?php echo e($moderacao->pergunta->texto); ?></p>
            <p class="text-secondary small mb-2">Motivo da denúncia: <?php echo e($moderacao->motivo); ?></p>
            <div class="d-flex justify-content-between align-items-center">
                <span class="badge <?php echo e($moderacao->status === 'analisando' ? 'bg-warning text-dark' : ($moderacao->status === 'aprovada' ? 'bg-success' : 'bg-danger')); ?>">
                    <?php echo e(ucfirst($moderacao->status)); ?>

                </span>
                <div class="d-flex gap-2">
                    <?php $__currentLoopData = ['aprovada' => ['Manter pergunta', 'btn-outline-success'], 'rejeitada' => ['Remover pergunta', 'btn-outline-danger']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor => [$rotulo, $classe]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <form action="<?php echo e(route('moderacoes.status', $moderacao)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input type="hidden" name="status" value="<?php echo e($valor); ?>">
                            <button type="submit" class="btn btn-sm <?php echo e($classe); ?>"><?php echo e($rotulo); ?></button>
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="alert alert-dark text-center p-4">Nenhuma denúncia por aqui.</div>
<?php endif; ?>

<div class="d-flex justify-content-center mt-4"><?php echo e($moderacoes->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/claude/falaq/falaq-base-main/resources/views/eventos/moderacoes.blade.php ENDPATH**/ ?>
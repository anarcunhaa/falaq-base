
<button <?php echo e($attributes->merge(['type' => 'submit', 'class' => 'btn btn-danger btn-sm fw-bold'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH /home/claude/falaq/falaq-base-main/resources/views/components/danger-button.blade.php ENDPATH**/ ?>